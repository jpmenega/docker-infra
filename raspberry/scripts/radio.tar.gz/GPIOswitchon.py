import RPi.GPIO as GPIO
import time
import sys

pin = 16

GPIO.setmode(GPIO.BOARD)

if sys.argv[1] == '1':
    pin = 16
elif sys.argv[1] == '2':
    pin = 18

GPIO.setwarnings(False)
GPIO.setup(pin, GPIO.OUT)

if sys.argv[2] == "False":
    GPIO.output(pin, True)
else:
    GPIO.output(pin, False)

