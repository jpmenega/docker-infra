#!/bin/bash

/usr/bin/python3 /etc/zabbix/scripts/GPIOswitchon.py 1 True
sleep 3
/usr/bin/python3 /etc/zabbix/scripts/GPIOswitchon.py 1 False
