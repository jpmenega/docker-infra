#!/bin/bash

/usr/bin/python3 /etc/zabbix/scripts/GPIOswitchon.py 1 False
